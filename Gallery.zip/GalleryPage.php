<!doctype html>
<!--[if IE]><![endif]-->
<!--[if lt IE 7 ]> <html lang="en" class="ie6">    <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7">    <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8">    <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="ie9">    <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html class="no-js" lang="en">

<head>
    <?php include('layout/links.php');?>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        /* Gallery Page Custom Styles */
        .gallery-hero {
            background: linear-gradient(rgba(139, 26, 26, 0.75), rgba(107, 20, 20, 0.75)),
                        url('https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=1600&h=800&fit=crop');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            color: white;
            padding: 140px 0;
            text-align: center;
            position: relative;
        }

        .gallery-hero::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.1);
        }

        .gallery-hero .container {
            position: relative;
            z-index: 1;
        }

        .gallery-hero-title {
            font-size: 3.8rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.4);
            letter-spacing: 1px;
            font-family: 'Poppins', sans-serif;
            animation: galFadeInUp 1s ease-out;
        }

        .gallery-hero-subtitle {
            font-size: 1.6rem;
            font-weight: 300;
            opacity: 0.95;
            margin-bottom: 30px;
            letter-spacing: 0.5px;
            font-family: 'Poppins', sans-serif;
            animation: galFadeInUp 1s ease-out 0.2s both;
        }

        .gallery-hero-divider {
            width: 100px;
            height: 4px;
            background: white;
            margin: 0 auto;
            border-radius: 2px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
            animation: galFadeInUp 1s ease-out 0.4s both;
        }

        .gallery-hero-breadcrumb {
            list-style: none;
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            animation: galFadeInUp 1s ease-out 0.5s both;
        }

        .gallery-hero-breadcrumb li {
            font-size: 1rem;
            opacity: 0.9;
        }

        .gallery-hero-breadcrumb li a {
            color: white;
            text-decoration: none;
            transition: opacity 0.3s;
        }

        .gallery-hero-breadcrumb li a:hover {
            opacity: 0.7;
        }

        .gallery-hero-breadcrumb li.active {
            font-weight: 600;
        }

        .gallery-hero-breadcrumb li + li::before {
            content: '/';
            margin-right: 10px;
            opacity: 0.6;
        }

        /* Filter Section */
        .gal-filter-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            padding: 80px 0 40px;
            position: relative;
            overflow: hidden;
        }

        .gal-filter-section::before {
            content: '';
            position: absolute;
            top: -100px;
            right: -100px;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(139, 26, 26, 0.05) 0%, transparent 70%);
            border-radius: 50%;
            animation: galFloat 8s ease-in-out infinite;
        }

        .gal-section-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .gal-section-title {
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 15px;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50 0%, #8B1A1A 50%, #2c3e50 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: galGradientShift 3s ease infinite;
            background-size: 200% auto;
        }

        .gal-title-underline {
            width: 80px;
            height: 4px;
            background: linear-gradient(135deg, #8B1A1A 0%, #A52A2A 50%, #6B1414 100%);
            margin: 0 auto;
            border-radius: 2px;
            box-shadow: 0 2px 8px rgba(139, 26, 26, 0.3);
        }

        .gal-description {
            text-align: center;
            font-size: 1.1rem;
            color: #666;
            max-width: 800px;
            margin: 0 auto 40px;
            line-height: 1.8;
            font-family: 'Poppins', sans-serif;
        }

        .gal-filters {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 30px;
        }

        .gal-filters .filter {
            position: relative;
            padding: 14px 35px;
            background: white;
            color: #2c3e50;
            border: 2px solid transparent;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            font-family: 'Poppins', sans-serif;
            overflow: hidden;
            z-index: 1;
            display: inline-block;
        }

        .gal-filters .filter::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #8B1A1A 0%, #A52A2A 50%, #6B1414 100%);
            transform: scaleX(0);
            transform-origin: right;
            transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: -1;
        }

        .gal-filters .filter:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(139, 26, 26, 0.3);
            color: white;
        }

        .gal-filters .filter:hover::before {
            transform: scaleX(1);
            transform-origin: left;
        }

        .gal-filters .filter.active {
            background: linear-gradient(135deg, #8B1A1A 0%, #A52A2A 50%, #6B1414 100%);
            color: white;
            box-shadow: 0 12px 25px rgba(139, 26, 26, 0.35);
            transform: translateY(-3px);
        }

        /* Gallery Grid Section */
        .gal-grid-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 40px 0 80px;
            position: relative;
        }

        .gal-grid-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #8B1A1A 0%, #A52A2A 50%, #6B1414 100%);
        }

        .gal-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 30px;
            margin-top: 20px;
        }

        .gal-grid .modern-gallery-item {
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            animation: galFadeInUp 0.8s ease-out both;
        }

        .gal-item-inner {
            position: relative;
            width: 100%;
            height: 300px;
            overflow: hidden;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .gal-item-inner img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .gal-item-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(139, 26, 26, 0.95) 0%, rgba(165, 42, 42, 0.85) 50%, rgba(107, 20, 20, 0.95) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.5s ease;
            text-decoration: none;
        }

        .gal-overlay-content {
            text-align: center;
            transform: scale(0.8);
            transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .gal-overlay-icon {
            font-size: 3rem;
            display: block;
            margin-bottom: 15px;
            filter: drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.3));
            animation: galBounce 2s ease-in-out infinite;
        }

        .gal-overlay-category {
            color: white;
            font-size: 1.3rem;
            font-weight: 600;
            text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.4);
            display: block;
            letter-spacing: 1px;
            font-family: 'Poppins', sans-serif;
        }

        .modern-gallery-item:hover .gal-item-inner {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 35px rgba(139, 26, 26, 0.4);
        }

        .modern-gallery-item:hover .gal-item-inner img {
            transform: scale(1.15) rotate(2deg);
        }

        .modern-gallery-item:hover .gal-item-overlay {
            opacity: 1;
        }

        .modern-gallery-item:hover .gal-overlay-content {
            transform: scale(1);
        }

        /* Animations */
        @keyframes galFadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes galFloat {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        @keyframes galGradientShift {
            0%, 100% { background-position: 0% center; }
            50% { background-position: 100% center; }
        }

        @keyframes galBounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .gal-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .gallery-hero {
                background-attachment: scroll;
                padding: 80px 0;
            }

            .gallery-hero-title {
                font-size: 2.5rem;
            }

            .gallery-hero-subtitle {
                font-size: 1.2rem;
            }

            .gal-section-title {
                font-size: 2rem;
            }

            .gal-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
            }

            .gal-item-inner {
                height: 200px;
            }

            .gal-filters {
                gap: 10px;
            }

            .gal-filters .filter {
                padding: 10px 20px;
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .gallery-hero-title {
                font-size: 2rem;
            }

            .gal-section-title {
                font-size: 1.8rem;
            }

            .gal-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .gal-item-inner {
                height: 150px;
                border-radius: 12px;
            }

            .gal-filters .filter {
                padding: 8px 16px;
                font-size: 0.85rem;
            }

            .gal-overlay-icon {
                font-size: 2rem;
            }

            .gal-overlay-category {
                font-size: 1rem;
            }
        }
    </style>
</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <!-- Start main area -->
    <div class="main-area">
        <!-- Start header -->
        <?php include('layout/header.php'); ?>
        <!-- End header -->

        <!-- Hero Section -->
        <section class="gallery-hero">
            <div class="container">
                <h1 class="gallery-hero-title">Our Gallery</h1>
                <p class="gallery-hero-subtitle">Explore moments captured from our work and the lives we touch</p>
                <div class="gallery-hero-divider"></div>
                <ul class="gallery-hero-breadcrumb">
                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                    <li class="active">Gallery</li>
                </ul>
            </div>
        </section>

        <!-- Gallery Filter Section -->
        <section class="gal-filter-section">
            <div class="container">
                <div class="gal-section-header">
                    <h2 class="gal-section-title">Our Gallery</h2>
                    <div class="gal-title-underline"></div>
                </div>
                <p class="gal-description">Explore moments captured from our work and the lives we touch, showing the heart of our mission in action.</p>

                <!-- MixItUp Container -->
                <div id="gallery-filter">
                    <!-- Filter Buttons -->
                    <div class="gal-filters">
                        <span class="filter active" data-filter="all">All</span>
                        <span class="filter" data-filter="Mosques">Mosques</span>
                        <span class="filter" data-filter="Flood">Flood Relief</span>
                        <span class="filter" data-filter="Education">Education</span>
                        <span class="filter" data-filter="Rashan">Food Package</span>
                        <span class="filter" data-filter="House">House</span>
                        <span class="filter" data-filter="Water">Water</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Gallery Grid Section -->
        <section class="gal-grid-section">
            <div class="container">
                <div class="gal-grid" id="gallery-grid">
                <?php
                if ($allnode) {
                    foreach ($allnode as $key => $nod) {
                        // Map category to emoji icon
                        $icon = '📷';
                        $cat = $nod->gal_title;
                        if ($cat == 'Mosques') $icon = '🕌';
                        elseif ($cat == 'Flood') $icon = '🌊';
                        elseif ($cat == 'Education') $icon = '📚';
                        elseif ($cat == 'Rashan') $icon = '🍚';
                        elseif ($cat == 'House') $icon = '🏠';
                        elseif ($cat == 'Water') $icon = '💧';
                        ?>
                        <div class="modern-gallery-item mix all <?php echo $nod->gal_title; ?> Wildlife">
                            <div class="gal-item-inner">
                                <img src="<?php echo base_url('upload/gallery/'.$nod->gal_img); ?>" alt="<?php echo $nod->gal_title; ?>" />
                                <a class="gal-item-overlay image-link" href="<?php echo base_url('upload/gallery/'.$nod->gal_img); ?>">
                                    <div class="gal-overlay-content">
                                        <span class="gal-overlay-icon"><?php echo $icon; ?></span>
                                        <span class="gal-overlay-category"><?php echo $nod->gal_title; ?></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
                </div>
            </div>
        </section>

        <!-- Start footer -->
        <?php include('layout/footer.php'); ?>
        <!-- End footer -->

    </div>
    <!-- End main area -->

    <?php include('layout/script.php'); ?>
</body>

</html>