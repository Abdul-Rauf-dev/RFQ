// RAFIQ FOUNDATION ADMIN PANEL
// Complete Working Script with All Features
// ============================================

// ============================================
// TOAST NOTIFICATION (Global)
// ============================================

function showToast(message, icon = "fa-check-circle") {
    let toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${message}`;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add("show"), 100);
    setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// ============================================
// LOCAL STORAGE DATABASE
// ============================================

let achievements = JSON.parse(localStorage.getItem("achievements")) || [];
let gallery = JSON.parse(localStorage.getItem("gallery")) || [];
let volunteers = JSON.parse(localStorage.getItem("volunteers")) || [];
let team = JSON.parse(localStorage.getItem("team")) || [];
let events = JSON.parse(localStorage.getItem("events")) || [];
let donations = JSON.parse(localStorage.getItem("donations")) || [];
let donors = JSON.parse(localStorage.getItem("donors")) || [];
let messages = JSON.parse(localStorage.getItem("messages")) || [];
let notifications = JSON.parse(localStorage.getItem("notifications")) || [];
let settings = JSON.parse(localStorage.getItem("settings")) || {};

function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}

// ============================================
// SEED DEFAULT DATA
// ============================================

function seedDefaultData() {
    if (!localStorage.getItem("achievements")) {
        achievements = [
            { id: 1, title: "Clean Water Program", description: "Hand Pumps: 3955, Water Plants: 1072", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731858_aba0b8fdeef464fdeaae.jpg" },
            { id: 2, title: "Community Services", description: "Masajid: 1207, Aftar/Rashan: 899, Qurbani: 309", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731886_a3c655bcb33dec4fbbe6.jpg" },
            { id: 3, title: "Educational Projects", description: "Schools: 42, Educational Complex: 20", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731901_9062f48c4bf6a2e4f2e5.jpg" },
            { id: 4, title: "Humanitarian Projects", description: "Houses: 14, Eid Gifts: 2", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731915_4b5a8f7a40e99240ff35.jpg" },
            { id: 5, title: "Health Services", description: "Medical Camp: 2, Dispensary: 1", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731931_d1b30f3c39dd2072e737.jpg" },
            { id: 6, title: "Sponsorships", description: "Orphan Care: 16, Imam: 4", date: "2025", image: "https://rafiqfoundation.org/upload/achievements/1747731945_80e9d1de66ab4fd6c33c.jpg" }
        ];
        saveData("achievements", achievements);
    }

    if (!localStorage.getItem("gallery")) {
        gallery = [
            { id: 1, image: "https://rafiqfoundation.org/upload/gallery/1747808060_a8860058da7be4ad8c8b.jpg", title: "Rashan", date: "2025", category: "Rashan" },
            { id: 2, image: "https://rafiqfoundation.org/upload/gallery/1747808036_562d553225bee9b299fe.jpg", title: "Flood Relief", date: "2025", category: "Flood Relief" },
            { id: 3, image: "https://rafiqfoundation.org/upload/gallery/1747808192_5c9654c9edb8813bfb57.jpg", title: "Education", date: "2025", category: "Education" },
            { id: 4, image: "https://rafiqfoundation.org/upload/gallery/1747807984_ec1074fee14d8573d80d.jpg", title: "Mosques", date: "2025", category: "Mosques" },
            { id: 5, image: "https://rafiqfoundation.org/upload/gallery/1747808996_2fac72539caeead5538b.jpg", title: "House", date: "2025", category: "House" },
            { id: 6, image: "https://rafiqfoundation.org/upload/gallery/1747808025_f83695eee0b9492be582.jpg", title: "Flood Relief", date: "2025", category: "Flood Relief" },
            { id: 7, image: "https://rafiqfoundation.org/upload/gallery/1747808990_7dee717ac5a835b18d23.jpg", title: "House", date: "2025", category: "House" },
            { id: 8, image: "https://rafiqfoundation.org/upload/gallery/1747808042_d12f15256289bfcdc349.jpg", title: "Flood Relief", date: "2025", category: "Flood Relief" }
        ];
        saveData("gallery", gallery);
    }

    if (!localStorage.getItem("volunteers")) {
        volunteers = [
            { id: 1, name: "Hafiz Ahmad Mehmood", role: "Chairman Rafiq Foundation", email: "", phone: "", image: "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png" },
            { id: 2, name: "Hafiz Ehsan Rafiq", role: "Executive Member", email: "", phone: "", image: "https://rafiqfoundation.org/upload/team/1747734113_76612e0489db8b7db9c0.png" },
            { id: 3, name: "Hafeez ul Rehman Hamdani", role: "General Secretary", email: "", phone: "", image: "https://rafiqfoundation.org/upload/team/1747734136_2cdc2e1646f25c199c3c.png" },
            { id: 4, name: "Mujahid Mustafa", role: "Manager Admin", email: "", phone: "", image: "https://rafiqfoundation.org/upload/team/1747734149_18bd7ddf1a9166f77889.png" }
        ];
        saveData("volunteers", volunteers);
    }

    if (!localStorage.getItem("team")) {
        team = [
            { id: 1, name: "Hafiz Ahmad Mehmood", role: "Founder & Chairman", email: "info@rafiqfoundation.org", phone: "+92-300-1234567", image: "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png", bio: "Visionary leader dedicated to serving humanity" },
            { id: 2, name: "Hafiz Ehsan Rafiq", role: "Executive Director", email: "ehsan@rafiqfoundation.org", phone: "+92-301-2345678", image: "https://rafiqfoundation.org/upload/team/1747734113_76612e0489db8b7db9c0.png", bio: "Leading strategic initiatives and operations" },
            { id: 3, name: "Hafeez ul Rehman Hamdani", role: "General Secretary", email: "hafeez@rafiqfoundation.org", phone: "+92-302-3456789", image: "https://rafiqfoundation.org/upload/team/1747734136_2cdc2e1646f25c199c3c.png", bio: "Managing organizational affairs and documentation" },
            { id: 4, name: "Mujahid Mustafa", role: "Admin Manager", email: "mujahid@rafiqfoundation.org", phone: "+92-303-4567890", image: "https://rafiqfoundation.org/upload/team/1747734149_18bd7ddf1a9166f77889.png", bio: "Overseeing administrative operations" }
        ];
        saveData("team", team);
    }

    if (!localStorage.getItem("events")) {
        events = [
            { id: 1, title: "Eid Gifts Distribution", date: "21 May 2026", image: "https://rafiqfoundation.org/upload/gallery/1747808060_a8860058da7be4ad8c8b.jpg" },
            { id: 2, title: "Emergency Care on Wheels", date: "05 Jun 2026", image: "https://rafiqfoundation.org/upload/achievements/1747731886_a3c655bcb33dec4fbbe6.jpg" },
            { id: 3, title: "Food for All: Rashan Distribution Drive", date: "05 Jun 2026", image: "https://rafiqfoundation.org/upload/gallery/1747808036_562d553225bee9b299fe.jpg" }
        ];
        saveData("events", events);
    }

    if (!localStorage.getItem("donations")) {
        donations = [
            { id: 1, title: "Clean Water for Rural Areas", goal: 50000, collected: 32500, description: "Building hand pumps and water plants in underserved communities", date: "15-05-2026", image: "https://rafiqfoundation.org/upload/achievements/1747731858_aba0b8fdeef464fdeaae.jpg" },
            { id: 2, title: "Education for All Campaign", goal: 75000, collected: 48000, description: "Supporting schools and educational complexes for underprivileged children", date: "18-05-2026", image: "https://rafiqfoundation.org/upload/achievements/1747731901_9062f48c4bf6a2e4f2e5.jpg" },
            { id: 3, title: "Flood Relief Emergency Fund", goal: 100000, collected: 87500, description: "Providing immediate relief to flood-affected families", date: "20-05-2026", image: "https://rafiqfoundation.org/upload/gallery/1747808036_562d553225bee9b299fe.jpg" },
            { id: 4, title: "Mosque Construction Project", goal: 150000, collected: 92000, description: "Building mosques to serve local communities", date: "22-05-2026", image: "https://rafiqfoundation.org/upload/gallery/1747807984_ec1074fee14d8573d80d.jpg" },
            { id: 5, title: "Orphan Sponsorship Program", goal: 30000, collected: 18500, description: "Monthly support for orphaned children", date: "24-05-2026", image: "https://rafiqfoundation.org/upload/achievements/1747731945_80e9d1de66ab4fd6c33c.jpg" }
        ];
        saveData("donations", donations);
    }

    if (!localStorage.getItem("donors")) {
        donors = [
            { id: 1, name: "Ahmed Khan", email: "ahmed.khan@example.com", phone: "+92-310-1234567", amount: 50000, date: "15-05-2026", address: "Karachi, Pakistan", image: "" },
            { id: 2, name: "Ali Raza", email: "ali.raza@example.com", phone: "+92-311-2345678", amount: 35000, date: "18-05-2026", address: "Lahore, Pakistan", image: "" },
            { id: 3, name: "Fatima Noor", email: "fatima.noor@example.com", phone: "+92-312-3456789", amount: 75000, date: "20-05-2026", address: "Islamabad, Pakistan", image: "" },
            { id: 4, name: "Zainab Ali", email: "zainab.ali@example.com", phone: "+92-313-4567890", amount: 120000, date: "22-05-2026", address: "Peshawar, Pakistan", image: "" },
            { id: 5, name: "Usman Ghani", email: "usman.ghani@example.com", phone: "+92-314-5678901", amount: 25000, date: "24-05-2026", address: "Multan, Pakistan", image: "" },
            { id: 6, name: "Maryam Siddiqui", email: "maryam.s@example.com", phone: "+92-315-6789012", amount: 90000, date: "25-05-2026", address: "Faisalabad, Pakistan", image: "" }
        ];
        saveData("donors", donors);
    }

    if (!localStorage.getItem("messages")) {
        messages = [
            { id: 1, name: "Muhammad Sarfaraz", email: "sarfaraz@example.com", message: "Being a volunteer at Rafiq Foundation has been one of the most rewarding parts of my life.", date: "20-05-2026", read: false },
            { id: 2, name: "Muhammad Ishfaq", email: "ishfaq@example.com", message: "Working with Rafiq Foundation has opened my eyes to the real meaning of humanity.", date: "22-05-2026", read: false },
            { id: 3, name: "Ahmed Ali", email: "ahmed@example.com", message: "Would like to donate for education program.", date: "25-05-2026", read: false }
        ];
        saveData("messages", messages);
    }

    if (!localStorage.getItem("notifications")) {
        notifications = [
            { id: 1, text: "New donation received from Ahmed Khan - $500", time: "2 min ago", icon: "fa-hand-holding-heart", read: false },
            { id: 2, text: "New volunteer Hafiz Ahmad Mehmood registered", time: "15 min ago", icon: "fa-user-plus", read: false },
            { id: 3, text: "Gallery updated with 3 new images", time: "1 hour ago", icon: "fa-image", read: false },
            { id: 4, text: "Event 'Eid Gifts Distribution' created", time: "3 hours ago", icon: "fa-calendar", read: false },
            { id: 5, text: "New message from Muhammad Sarfaraz", time: "Yesterday", icon: "fa-envelope", read: false }
        ];
        saveData("notifications", notifications);
    }
}

seedDefaultData();

// ============================================
// DOM READY
// ============================================

document.addEventListener("DOMContentLoaded", () => {

    const loader = document.getElementById("loader");
    const sidebar = document.querySelector(".sidebar");
    const menuBtn = document.getElementById("menu-toggle");
    const darkBtn = document.getElementById("dark-mode-btn");
    const pages = document.querySelectorAll(".page-view");
    const navLinks = document.querySelectorAll(".nav-link");

    // ============================================
    // LOADER
    // ============================================

    window.addEventListener("load", () => {
        setTimeout(() => loader.classList.add("hide"), 700);
    });

    // ============================================
    // SIDEBAR TOGGLE
    // ============================================

    menuBtn?.addEventListener("click", () => sidebar.classList.toggle("open"));

    // ============================================
    // PAGE SWITCH
    // ============================================

    function switchPage(pageName) {
        pages.forEach(page => page.classList.remove("active"));
        navLinks.forEach(link => link.classList.remove("active"));

        const targetPage = document.getElementById(`page-${pageName}`);
        const targetLink = document.querySelector(`[data-page="${pageName}"]`);

        if (targetPage) targetPage.classList.add("active");
        if (targetLink) targetLink.classList.add("active");

        sidebar.classList.remove("open");
        document.title = `${pageName.charAt(0).toUpperCase() + pageName.slice(1)} | Rafiq Foundation`;

        // Scroll to top
        window.scrollTo({ top: 0, behavior: "smooth" });

        if (pageName === "reports") setTimeout(renderReportChart, 100);
        if (pageName === "donations") updateDonationSummary();
    }

    // Make switchPage available globally for search result clicks
    window.switchPage = switchPage;

    navLinks.forEach(link => {
        link.addEventListener("click", (e) => {
            e.preventDefault();
            switchPage(link.dataset.page);
        });
    });

    // ============================================
    // NOTIFICATION & MESSAGE BUTTON CLICKS
    // ============================================

    const notifBtn = document.getElementById("notif-btn");
    const msgBtn = document.getElementById("msg-btn");

    notifBtn?.addEventListener("click", () => switchPage("messages"));
    msgBtn?.addEventListener("click", () => switchPage("messages"));

    // ============================================
    // DARK MODE
    // ============================================

    if (localStorage.getItem("theme") === "dark") {
        document.body.classList.add("dark");
        const darkToggle = document.getElementById("dark-toggle-settings");
        if (darkToggle) darkToggle.checked = true;
    }

    darkBtn?.addEventListener("click", () => {
        document.body.classList.toggle("dark");
        const isDark = document.body.classList.contains("dark");
        localStorage.setItem("theme", isDark ? "dark" : "light");
        showToast(isDark ? "Dark Mode Enabled" : "Light Mode Enabled", isDark ? "fa-moon" : "fa-sun");
        // Sync settings toggle
        const darkToggle = document.getElementById("dark-toggle-settings");
        if (darkToggle) darkToggle.checked = isDark;
    });

    // Settings dark mode toggle
    const darkToggleSettings = document.getElementById("dark-toggle-settings");
    darkToggleSettings?.addEventListener("change", () => {
        document.body.classList.toggle("dark", darkToggleSettings.checked);
        localStorage.setItem("theme", darkToggleSettings.checked ? "dark" : "light");
        showToast(darkToggleSettings.checked ? "Dark Mode Enabled" : "Light Mode Enabled");
    });

    // ============================================
    // COUNTER ANIMATION
    // ============================================

    function animateCounter(id, value) {
        const element = document.getElementById(id);
        if (!element) return;
        const target = value || 0;
        let count = 0;
        const speed = Math.max(1, target / 60);
        const timer = setInterval(() => {
            count += speed;
            if (count >= target) { count = target; clearInterval(timer); }
            element.textContent = Math.floor(count);
        }, 20);
    }

    // ============================================
    // DONATIONS OVERVIEW CHART (replaces Visitors)
    // ============================================

    const chartCanvas = document.getElementById("overviewChart");
    let overviewChartInstance = null;

    function renderDonationsChart() {
        if (!chartCanvas || !window.Chart) return;
        if (overviewChartInstance) overviewChartInstance.destroy();

        const ctx = chartCanvas.getContext("2d");
        const gradient = ctx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, "rgba(91,20,35,.35)");
        gradient.addColorStop(1, "rgba(91,20,35,0)");

        const gradient2 = ctx.createLinearGradient(0, 0, 0, 300);
        gradient2.addColorStop(0, "rgba(212,175,55,.35)");
        gradient2.addColorStop(1, "rgba(212,175,55,0)");

        // Calculate monthly donation data
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
        const collected = [1200, 2800, 3500, 4100, 5200, 7300, donations.reduce((s, d) => s + (Number(d.collected) || 0), 0)];
        const goals = [5000, 6000, 7000, 8000, 10000, 12000, donations.reduce((s, d) => s + (Number(d.goal) || 0), 0)];

        overviewChartInstance = new Chart(ctx, {
            type: "line",
            data: {
                labels: months,
                datasets: [
                    {
                        label: "Collected",
                        data: collected,
                        borderColor: "#5b1423",
                        backgroundColor: gradient,
                        fill: true,
                        borderWidth: 3,
                        pointRadius: 5,
                        pointHoverRadius: 8,
                        pointBackgroundColor: "#d4af37",
                        tension: .4
                    },
                    {
                        label: "Goal",
                        data: goals,
                        borderColor: "#d4af37",
                        backgroundColor: gradient2,
                        fill: true,
                        borderWidth: 2,
                        borderDash: [8, 4],
                        pointRadius: 4,
                        pointHoverRadius: 7,
                        pointBackgroundColor: "#5b1423",
                        tension: .4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "top", labels: { usePointStyle: true, padding: 20 } }
                },
                scales: {
                    y: { beginAtZero: true, grid: { color: "rgba(0,0,0,.05)" } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    renderDonationsChart();

    // ============================================
    // REPORT CHART
    // ============================================

    // ============================================
    // RECENT ACTIVITIES (Dynamic)
    // ============================================

    let recentActivities = JSON.parse(localStorage.getItem("recentActivities")) || [];

    function addActivity(icon, text) {
        const activity = {
            icon: icon,
            text: text,
            time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
            date: new Date().toLocaleDateString()
        };
        recentActivities.unshift(activity);
        if (recentActivities.length > 10) recentActivities = recentActivities.slice(0, 10);
        localStorage.setItem("recentActivities", JSON.stringify(recentActivities));
        updateActivityList();
    }

    function updateActivityList() {
        const activityList = document.getElementById("activity-list");
        if (!activityList) return;
        if (recentActivities.length === 0) {
            activityList.innerHTML = `<li style="text-align:center;color:#999;padding:20px;">No recent activities</li>`;
            return;
        }
        activityList.innerHTML = recentActivities.map(activity => `
            <li>
                <i class="fa-solid ${activity.icon}"></i>
                ${activity.text}
                <span>${activity.time}</span>
            </li>
        `).join("");
    }

    // ============================================
    // REPORT CHARTS (Enhanced)
    // ============================================

    let reportChartInstance = null;
    let donationReportChartInstance = null;
    let trendChartInstance = null;

    function renderReportChart() {
        const reportCanvas = document.getElementById("reportChart");
        const donationCanvas = document.getElementById("donationReportChart");
        const trendCanvas = document.getElementById("trendChart");
        
        if (!reportCanvas || !window.Chart) return;
        if (reportChartInstance) reportChartInstance.destroy();
        if (donationReportChartInstance) donationReportChartInstance.destroy();
        if (trendChartInstance) trendChartInstance.destroy();

        // Update report summary cards
        document.getElementById("report-achievements").textContent = achievements.length;
        document.getElementById("report-gallery").textContent = gallery.length;
        document.getElementById("report-volunteers").textContent = volunteers.length + team.length;
        document.getElementById("report-events").textContent = events.length;

        // Data Overview Chart (Bar Chart)
        reportChartInstance = new Chart(reportCanvas, {
            type: "bar",
            data: {
                labels: ["Achievements", "Gallery", "Volunteers", "Events", "Projects"],
                datasets: [{
                    label: "Total Count",
                    data: [achievements.length, gallery.length, volunteers.length, events.length, donations.length],
                    backgroundColor: [
                        "rgba(91,20,35,0.8)",
                        "rgba(212,175,55,0.8)",
                        "rgba(34,197,94,0.8)",
                        "rgba(245,158,11,0.8)",
                        "rgba(59,130,246,0.8)"
                    ],
                    borderColor: [
                        "rgb(91,20,35)",
                        "rgb(212,175,55)",
                        "rgb(34,197,94)",
                        "rgb(245,158,11)",
                        "rgb(59,130,246)"
                    ],
                    borderWidth: 2,
                    borderRadius: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: "rgba(0,0,0,.05)" },
                        ticks: { font: { size: 12 } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 12 } }
                    }
                }
            }
        });

        // Donations Analysis Chart (Doughnut)
        if (donationCanvas) {
            const totalCollected = donations.reduce((s, d) => s + (Number(d.collected) || 0), 0);
            const totalGoal = donations.reduce((s, d) => s + (Number(d.goal) || 0), 0);
            const remaining = Math.max(0, totalGoal - totalCollected);

            donationReportChartInstance = new Chart(donationCanvas, {
                type: "doughnut",
                data: {
                    labels: ["Collected", "Remaining"],
                    datasets: [{
                        data: [totalCollected, remaining],
                        backgroundColor: ["rgba(34,197,94,0.8)", "rgba(239,68,68,0.8)"],
                        borderColor: ["rgb(34,197,94)", "rgb(239,68,68)"],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: "bottom",
                            labels: { padding: 20, font: { size: 13 } }
                        }
                    }
                }
            });
        }

        // Monthly Trends Chart (Line)
        if (trendCanvas) {
            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
            const collected = [1200, 2800, 3500, 4100, 5200, 7300, donations.reduce((s, d) => s + (Number(d.collected) || 0), 0)];
            const goals = [5000, 6000, 7000, 8000, 10000, 12000, donations.reduce((s, d) => s + (Number(d.goal) || 0), 0)];

            trendChartInstance = new Chart(trendCanvas, {
                type: "line",
                data: {
                    labels: months,
                    datasets: [
                        {
                            label: "Collected",
                            data: collected,
                            borderColor: "#22c55e",
                            backgroundColor: "rgba(34,197,94,0.1)",
                            fill: true,
                            borderWidth: 3,
                            pointRadius: 5,
                            pointHoverRadius: 8,
                            tension: .4
                        },
                        {
                            label: "Goal",
                            data: goals,
                            borderColor: "#5b1423",
                            backgroundColor: "rgba(91,20,35,0.1)",
                            fill: true,
                            borderWidth: 2,
                            borderDash: [8, 4],
                            pointRadius: 4,
                            tension: .4
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: "top", labels: { usePointStyle: true, padding: 20 } }
                    },
                    scales: {
                        y: { beginAtZero: true, grid: { color: "rgba(0,0,0,.05)" } },
                        x: { grid: { display: false } }
                    }
                }
            });
        }
    }

    // ============================================
    // GLOBAL SEARCH
    // ============================================

    const searchInput = document.getElementById("global-search");
    const searchResults = document.getElementById("search-results");

    if (searchInput) {
        searchInput.addEventListener("input", function () {
            const value = this.value.toLowerCase().trim();
            if (!value) { searchResults.classList.remove("active"); return; }

            let results = [];

            // Search achievements
            achievements.forEach(item => {
                if ((item.title || "").toLowerCase().includes(value) || (item.description || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-trophy", title: item.title, sub: item.description || "", page: "achievements", type: "Achievement" });
                }
            });

            // Search gallery
            gallery.forEach(item => {
                if ((item.title || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-image", title: item.title || "Gallery Image", sub: item.date || "", page: "gallery", type: "Gallery" });
                }
            });

            // Search volunteers
            volunteers.forEach(item => {
                if ((item.name || "").toLowerCase().includes(value) || (item.role || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-user", title: item.name, sub: item.role || "", page: "volunteers", type: "Volunteer" });
                }
            });

            // Search team
            team.forEach(item => {
                if ((item.name || "").toLowerCase().includes(value) || (item.role || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-user-tie", title: item.name, sub: item.role || "", page: "team", type: "Team" });
                }
            });

            // Search donors
            donors.forEach(item => {
                if ((item.name || "").toLowerCase().includes(value) || (item.email || "").toLowerCase().includes(value) || (item.phone || "").includes(value)) {
                    results.push({ icon: "fa-user-heart", title: item.name, sub: `Donated: $${(item.amount || 0).toLocaleString()}`, page: "donors", type: "Donor" });
                }
            });

            // Search events
            events.forEach(item => {
                if ((item.title || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-calendar", title: item.title, sub: item.date || "", page: "events", type: "Event" });
                }
            });

            // Search donations
            donations.forEach(item => {
                if ((item.title || "").toLowerCase().includes(value) || (item.description || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-hand-holding-heart", title: item.title, sub: `Goal: $${(item.goal || 0).toLocaleString()}`, page: "donations", type: "Project" });
                }
            });

            // Search messages
            messages.forEach(item => {
                if ((item.name || "").toLowerCase().includes(value) || (item.message || "").toLowerCase().includes(value) || (item.email || "").toLowerCase().includes(value)) {
                    results.push({ icon: "fa-envelope", title: item.name, sub: (item.message || "").substring(0, 50) + "...", page: "messages", type: "Message" });
                }
            });

            // Search settings
            if (value.includes("setting") || value.includes("organization") || value.includes("password") || value.includes("admin") || value.includes("config")) {
                results.push({ icon: "fa-gear", title: "Settings", sub: "Go to Settings page", page: "settings", type: "Page" });
            }

            // Search reports
            if (value.includes("report") || value.includes("analytics") || value.includes("chart") || value.includes("graph") || value.includes("statistics")) {
                results.push({ icon: "fa-chart-line", title: "Reports", sub: "View Analytics Report", page: "reports", type: "Page" });
            }

            // Search dashboard
            if (value.includes("dashboard") || value.includes("home") || value.includes("overview")) {
                results.push({ icon: "fa-house", title: "Dashboard", sub: "Go to Dashboard", page: "dashboard", type: "Page" });
            }

            // Search achievements page
            if (value.includes("achievement") || value.includes("trophy") || value.includes("milestone")) {
                results.push({ icon: "fa-trophy", title: "Achievements", sub: "Manage Achievements", page: "achievements", type: "Page" });
            }

            // Search gallery page
            if (value.includes("gallery") || value.includes("image") || value.includes("photo")) {
                results.push({ icon: "fa-image", title: "Gallery", sub: "Manage Gallery Images", page: "gallery", type: "Page" });
            }

            // Search volunteers page
            if (value.includes("volunteer") || value.includes("team") || value.includes("member")) {
                results.push({ icon: "fa-users", title: "Volunteers", sub: "Manage Volunteers", page: "volunteers", type: "Page" });
                results.push({ icon: "fa-user-tie", title: "Team", sub: "Manage Team Members", page: "team", type: "Page" });
            }

            // Search events page
            if (value.includes("event") || value.includes("calendar") || value.includes("schedule")) {
                results.push({ icon: "fa-calendar", title: "Events", sub: "Manage Events", page: "events", type: "Page" });
            }

            // Search donations page
            if (value.includes("donation") || value.includes("payment") || value.includes("contribution")) {
                results.push({ icon: "fa-hand-holding-heart", title: "Donations", sub: "Manage Donation Projects", page: "donations", type: "Page" });
                results.push({ icon: "fa-user-heart", title: "Donors", sub: "Manage Donors", page: "donors", type: "Page" });
            }

            // Search messages page
            if (value.includes("message") || value.includes("contact") || value.includes("inbox")) {
                results.push({ icon: "fa-envelope", title: "Messages", sub: "View Messages", page: "messages", type: "Page" });
            }

            // Render results
            if (results.length === 0) {
                searchResults.innerHTML = `<div class="search-no-result"><i class="fa-solid fa-search"></i><br>No results found for "${value}"</div>`;
            } else {
                searchResults.innerHTML = results.map(r => `
                    <div class="search-result-item" onclick="window.switchPage('${r.page}'); document.getElementById('search-results').classList.remove('active'); document.getElementById('global-search').value = '';">
                        <i class="fa-solid ${r.icon}"></i>
                        <div class="result-info">
                            <h4>${r.title}</h4>
                            <span>${r.type} &bull; ${r.sub}</span>
                        </div>
                    </div>
                `).join("");
            }
            searchResults.classList.add("active");
        });

        // Close search results on click outside
        document.addEventListener("click", (e) => {
            if (!e.target.closest(".search")) searchResults.classList.remove("active");
        });
    }

    // ============================================
    // UPDATE DASHBOARD COUNTS & BADGES
    // ============================================

    function updateDashboard() {
        const a = document.getElementById("achievements-count");
        const g = document.getElementById("gallery-count");
        const v = document.getElementById("volunteer-count");
        const ev = document.getElementById("events-count");

        if (a) a.innerText = achievements.length;
        if (g) g.innerText = gallery.length;
        if (v) v.innerText = volunteers.length;
        if (ev) ev.innerText = events.length;

        // Update notification & message badges
        const notifCount = document.getElementById("notif-count");
        const msgCount = document.getElementById("msg-count");
        const unreadNotifs = notifications.filter(n => !n.read).length;
        const unreadMsgs = messages.filter(m => !m.read).length;

        if (notifCount) {
            notifCount.textContent = unreadNotifs;
            notifCount.style.display = unreadNotifs > 0 ? "flex" : "none";
        }
        if (msgCount) {
            msgCount.textContent = unreadMsgs;
            msgCount.style.display = unreadMsgs > 0 ? "flex" : "none";
        }
    }

    // ============================================
    // UPDATE DONATION SUMMARY
    // ============================================

    function updateDonationSummary() {
        const totalGoal = donations.reduce((s, d) => s + (Number(d.goal) || 0), 0);
        const totalCollected = donations.reduce((s, d) => s + (Number(d.collected) || 0), 0);
        const pct = totalGoal > 0 ? Math.round((totalCollected / totalGoal) * 100) : 0;

        const goalEl = document.getElementById("donation-goal-total");
        const collectedEl = document.getElementById("donation-collected-total");
        const pctEl = document.getElementById("donation-progress-pct");
        const projectsEl = document.getElementById("donation-projects-count");

        if (goalEl) goalEl.textContent = `$${totalGoal.toLocaleString()}`;
        if (collectedEl) collectedEl.textContent = `$${totalCollected.toLocaleString()}`;
        if (pctEl) pctEl.textContent = `${pct}%`;
        if (projectsEl) projectsEl.textContent = donations.length;
    }

    // ============================================
    // MODAL SYSTEM
    // ============================================

    const modal = document.getElementById("adminModal");
    const modalTitle = document.getElementById("modalTitle");
    const modalFields = document.getElementById("modalFields");
    const modalForm = document.getElementById("modalForm");
    const closeModal = document.querySelector(".close-modal");
    let currentModalType = "";
    let editingId = null;

    function openModal(type, editId = null) {
        currentModalType = type;
        editingId = editId;
        modal.style.display = "flex";
        modalFields.innerHTML = "";

        const configs = {
            achievement: {
                title: editId ? "Edit Achievement" : "Add Achievement",
                fields: `
                    <input id="m-title" placeholder="Achievement Title" required>
                    <textarea id="m-desc" placeholder="Description" rows="3"></textarea>
                    <input id="m-image" placeholder="Image URL (e.g. https://example.com/image.jpg)">
                    <input id="m-date" placeholder="Date (e.g. 10 Jan 2026)">
                `
            },
            gallery: {
                title: editId ? "Edit Image" : "Upload Gallery Image",
                fields: `
                    <input id="m-image" placeholder="Image URL" required>
                    <input id="m-title" placeholder="Image Title">
                    <select id="m-category">
                        <option value="Rashan">Rashan</option>
                        <option value="Flood Relief">Flood Relief</option>
                        <option value="Education">Education</option>
                        <option value="Mosques">Mosques</option>
                        <option value="House">House</option>
                    </select>
                `
            },
            volunteer: {
                title: editId ? "Edit Volunteer" : "Add Volunteer",
                fields: `
                    <input id="m-name" placeholder="Name" required>
                    <input id="m-role" placeholder="Role" required>
                    <input id="m-email" placeholder="Email">
                    <input id="m-phone" placeholder="Phone">
                    <input id="m-image" placeholder="Image URL">
                `
            },
            event: {
                title: editId ? "Edit Event" : "Add Event",
                fields: `
                    <input id="m-title" placeholder="Event Name" required>
                    <input id="m-image" placeholder="Event Image URL">
                    <input id="m-date" type="date" required>
                `
            },
            donation: {
                title: editId ? "Edit Project" : "Add Donation Project",
                fields: `
                    <input id="m-title" placeholder="Project Title" required>
                    <textarea id="m-desc" placeholder="Project Description" rows="3"></textarea>
                    <input id="m-goal" placeholder="Required Amount ($)" required type="number" min="0">
                    <input id="m-collected" placeholder="Collected Amount ($)" required type="number" min="0">
                    <input id="m-image" placeholder="Project Image URL">
                `
            },
            team: {
                title: editId ? "Edit Team Member" : "Add Team Member",
                fields: `
                    <input id="m-name" placeholder="Name" required>
                    <input id="m-role" placeholder="Role / Designation" required>
                    <input id="m-email" placeholder="Email">
                    <input id="m-phone" placeholder="Phone">
                    <input id="m-image" placeholder="Image URL">
                    <textarea id="m-bio" placeholder="Short Bio" rows="2"></textarea>
                `
            },
            donor: {
                title: editId ? "Edit Donor" : "Add Donor",
                fields: `
                    <input id="m-name" placeholder="Donor Name" required>
                    <input id="m-email" placeholder="Email">
                    <input id="m-phone" placeholder="Phone Number">
                    <input id="m-amount" placeholder="Donation Amount ($)" type="number" min="0" required>
                    <input id="m-address" placeholder="Address">
                    <input id="m-image" placeholder="Photo URL">
                `
            }
        };

        const config = configs[type];
        if (!config) return;

        modalTitle.innerText = config.title;
        modalFields.innerHTML = config.fields;

        if (editId !== null) populateEditFields(type, editId);
    }

    function populateEditFields(type, id) {
        let item;
        if (type === "achievement") item = achievements.find(i => i.id === id);
        if (type === "volunteer") item = volunteers.find(i => i.id === id);
        if (type === "team") item = team.find(i => i.id === id);
        if (type === "donor") item = donors.find(i => i.id === id);
        if (type === "event") item = events.find(i => i.id === id);
        if (type === "donation") item = donations.find(i => i.id === id);
        if (type === "gallery") item = gallery.find(i => i.id === id);
        if (!item) return;

        if (type === "achievement") {
            document.getElementById("m-title").value = item.title || "";
            document.getElementById("m-desc").value = item.description || "";
            document.getElementById("m-image").value = item.image || "";
            document.getElementById("m-date").value = item.date || "";
        } else if (type === "gallery") {
            document.getElementById("m-image").value = item.image || "";
            document.getElementById("m-title").value = item.title || "";
            document.getElementById("m-category").value = item.category || "Rashan";
        } else if (type === "volunteer") {
            document.getElementById("m-name").value = item.name || "";
            document.getElementById("m-role").value = item.role || "";
            document.getElementById("m-email").value = item.email || "";
            document.getElementById("m-phone").value = item.phone || "";
            document.getElementById("m-image").value = item.image || "";
        } else if (type === "team") {
            document.getElementById("m-name").value = item.name || "";
            document.getElementById("m-role").value = item.role || "";
            document.getElementById("m-email").value = item.email || "";
            document.getElementById("m-phone").value = item.phone || "";
            document.getElementById("m-image").value = item.image || "";
            document.getElementById("m-bio").value = item.bio || "";
        } else if (type === "donor") {
            document.getElementById("m-name").value = item.name || "";
            document.getElementById("m-email").value = item.email || "";
            document.getElementById("m-phone").value = item.phone || "";
            document.getElementById("m-amount").value = item.amount || "";
            document.getElementById("m-address").value = item.address || "";
            document.getElementById("m-image").value = item.image || "";
        } else if (type === "event") {
            document.getElementById("m-title").value = item.title || "";
            document.getElementById("m-date").value = item.date || "";
            document.getElementById("m-image").value = item.image || "";
        } else if (type === "donation") {
            document.getElementById("m-title").value = item.title || "";
            document.getElementById("m-desc").value = item.description || "";
            document.getElementById("m-goal").value = item.goal || "";
            document.getElementById("m-collected").value = item.collected || "";
            document.getElementById("m-image").value = item.image || "";
        }
    }

    function closeModalFn() {
        modal.style.display = "none";
        editingId = null;
    }

    closeModal.onclick = closeModalFn;
    window.onclick = (e) => { if (e.target === modal) closeModalFn(); };

    // ============================================
    // MODAL FORM SUBMIT
    // ============================================

    modalForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const getVal = (id) => document.getElementById(id)?.value?.trim() || "";

        if (currentModalType === "achievement") {
            if (editingId) {
                let item = achievements.find(i => i.id === editingId);
                if (item) { item.title = getVal("m-title"); item.description = getVal("m-desc"); item.image = getVal("m-image"); item.date = getVal("m-date"); }
                addActivity("fa-trophy", "Achievement Updated: " + getVal("m-title"));
            } else {
                achievements.push({ id: Date.now(), title: getVal("m-title"), description: getVal("m-desc"), image: getVal("m-image"), date: getVal("m-date") || new Date().toLocaleDateString() });
                addActivity("fa-trophy", "New Achievement Added: " + getVal("m-title"));
            }
            saveData("achievements", achievements);
            displayAchievements();
            renderReportChart();
        }

        if (currentModalType === "gallery") {
            if (editingId) {
                let item = gallery.find(i => i.id === editingId);
                if (item) { item.image = getVal("m-image"); item.title = getVal("m-title"); item.category = getVal("m-category"); }
                addActivity("fa-image", "Gallery Image Updated");
            } else {
                gallery.push({ id: Date.now(), image: getVal("m-image"), title: getVal("m-title"), category: getVal("m-category"), date: new Date().toLocaleDateString() });
                addActivity("fa-image", "New Image Uploaded to Gallery");
            }
            saveData("gallery", gallery);
            displayGallery();
            renderReportChart();
        }

        if (currentModalType === "volunteer") {
            if (editingId) {
                let item = volunteers.find(i => i.id === editingId);
                if (item) { item.name = getVal("m-name"); item.role = getVal("m-role"); item.email = getVal("m-email"); item.phone = getVal("m-phone"); item.image = getVal("m-image") || "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png"; }
                addActivity("fa-user", "Volunteer Updated: " + getVal("m-name"));
            } else {
                volunteers.push({ id: Date.now(), name: getVal("m-name"), role: getVal("m-role"), email: getVal("m-email"), phone: getVal("m-phone"), image: getVal("m-image") || "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png" });
                addActivity("fa-user-plus", "New Volunteer Added: " + getVal("m-name"));
            }
            saveData("volunteers", volunteers);
            displayVolunteers();
            renderReportChart();
        }

        if (currentModalType === "event") {
            if (editingId) {
                let item = events.find(i => i.id === editingId);
                if (item) { item.title = getVal("m-title"); item.date = getVal("m-date"); item.image = getVal("m-image"); }
                addActivity("fa-calendar", "Event Updated: " + getVal("m-title"));
            } else {
                events.push({ id: Date.now(), title: getVal("m-title"), date: getVal("m-date"), image: getVal("m-image") });
                addActivity("fa-calendar-plus", "New Event Created: " + getVal("m-title"));
            }
            saveData("events", events);
            displayEvents();
            renderReportChart();
        }

        if (currentModalType === "donation") {
            const goal = Number(getVal("m-goal")) || 0;
            const collected = Number(getVal("m-collected")) || 0;
            if (editingId) {
                let item = donations.find(i => i.id === editingId);
                if (item) { item.title = getVal("m-title"); item.description = getVal("m-desc"); item.goal = goal; item.collected = collected; item.image = getVal("m-image"); }
                addActivity("fa-hand-holding-heart", "Project Updated: " + getVal("m-title"));
            } else {
                donations.push({ id: Date.now(), title: getVal("m-title"), description: getVal("m-desc"), goal: goal, collected: collected, image: getVal("m-image"), date: new Date().toLocaleDateString() });
                addActivity("fa-hand-holding-heart", "New Project Added: " + getVal("m-title"));
            }
            saveData("donations", donations);
            displayDonations();
            updateDonationSummary();
            renderDonationsChart();
            renderReportChart();
        }

        if (currentModalType === "team") {
            if (editingId) {
                let item = team.find(i => i.id === editingId);
                if (item) { item.name = getVal("m-name"); item.role = getVal("m-role"); item.email = getVal("m-email"); item.phone = getVal("m-phone"); item.image = getVal("m-image") || "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png"; item.bio = getVal("m-bio"); }
                addActivity("fa-user-tie", "Team Member Updated: " + getVal("m-name"));
            } else {
                team.push({ id: Date.now(), name: getVal("m-name"), role: getVal("m-role"), email: getVal("m-email"), phone: getVal("m-phone"), image: getVal("m-image") || "https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png", bio: getVal("m-bio") });
                addActivity("fa-user-tie", "New Team Member Added: " + getVal("m-name"));
            }
            saveData("team", team);
            displayTeam();
        }

        if (currentModalType === "donor") {
            if (editingId) {
                let item = donors.find(i => i.id === editingId);
                if (item) { item.name = getVal("m-name"); item.email = getVal("m-email"); item.phone = getVal("m-phone"); item.amount = Number(getVal("m-amount")) || 0; item.address = getVal("m-address"); item.image = getVal("m-image"); }
                addActivity("fa-user-heart", "Donor Updated: " + getVal("m-name"));
            } else {
                donors.push({ id: Date.now(), name: getVal("m-name"), email: getVal("m-email"), phone: getVal("m-phone"), amount: Number(getVal("m-amount")) || 0, address: getVal("m-address"), image: getVal("m-image"), date: new Date().toLocaleDateString() });
                addActivity("fa-user-heart", "New Donor Added: " + getVal("m-name"));
            }
            saveData("donors", donors);
            displayDonors();
        }

        updateDashboard();
        closeModalFn();
        showToast("Data Saved Successfully!");
    });

    // ============================================
    // BUTTON CONNECTIONS
    // ============================================

    document.querySelector(".add-achievement-btn")?.addEventListener("click", () => openModal("achievement"));
    document.querySelector(".add-gallery-btn")?.addEventListener("click", () => openModal("gallery"));
    document.querySelector(".add-volunteer-btn")?.addEventListener("click", () => openModal("volunteer"));
    document.querySelector(".add-team-btn")?.addEventListener("click", () => openModal("team"));
    document.querySelector(".add-donor-btn")?.addEventListener("click", () => openModal("donor"));
    document.querySelector(".add-event-btn")?.addEventListener("click", () => openModal("event"));
    document.querySelector(".add-donation-btn")?.addEventListener("click", () => openModal("donation"));

    // ============================================
    // DISPLAY ACHIEVEMENTS
    // ============================================

    function displayAchievements() {
        const tbody = document.getElementById("achievements-tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        if (achievements.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#999;padding:40px;">No achievements yet.</td></tr>`;
            return;
        }
        achievements.forEach((item, index) => {
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${item.image ? `<img src="${item.image}" alt="${item.title}" style="width:60px;height:60px;object-fit:cover;border-radius:10px;border:2px solid var(--border);">` : '<span style="color:#999;">No Image</span>'}</td>
                    <td><strong>${item.title}</strong></td>
                    <td>${item.description || "-"}</td>
                    <td>${item.date}</td>
                    <td>
                        <button onclick="editAchievement(${item.id})"><i class="fa-solid fa-pen"></i></button>
                        <button onclick="deleteAchievement(${item.id})"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>`;
        });
    }

    window.deleteAchievement = function (id) {
        if (!confirm("Delete this achievement?")) return;
        const item = achievements.find(i => i.id === id);
        achievements = achievements.filter(i => i.id !== id);
        saveData("achievements", achievements);
        displayAchievements(); updateDashboard(); renderReportChart();
        addActivity("fa-trash", "Achievement Deleted: " + (item?.title || "Unknown"));
        showToast("Achievement Deleted!", "fa-trash");
    };
    window.editAchievement = function (id) { openModal("achievement", id); };

    // ============================================
    // DISPLAY GALLERY
    // ============================================

    function displayGallery() {
        const grid = document.getElementById("gallery-grid");
        if (!grid) return;
        grid.innerHTML = "";
        if (gallery.length === 0) {
            grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-image"></i><h2>No Images</h2></div>`;
            return;
        }
        gallery.forEach(item => {
            grid.innerHTML += `
                <div class="gallery-card">
                    <img src="${item.image}" alt="${item.title || 'Gallery'}">
                    <div class="gallery-category">${item.category || 'Uncategorized'}</div>
                    <div class="overlay">
                        <button onclick="previewImage('${item.image}')"><i class="fa-solid fa-eye"></i></button>
                        <button onclick="editGalleryItem(${item.id})"><i class="fa-solid fa-pen"></i></button>
                        <button onclick="deleteGalleryItem(${item.id})"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>`;
        });
    }

    // Gallery category filtering
    const filterBtns = document.querySelectorAll(".filter-btn");
    filterBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            filterBtns.forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            const category = btn.dataset.category;
            const grid = document.getElementById("gallery-grid");
            if (!grid) return;
            grid.innerHTML = "";
            const filtered = category === "all" ? gallery : gallery.filter(item => item.category === category);
            if (filtered.length === 0) {
                grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-image"></i><h2>No Images in ${category}</h2></div>`;
                return;
            }
            filtered.forEach(item => {
                grid.innerHTML += `
                    <div class="gallery-card">
                        <img src="${item.image}" alt="${item.title || 'Gallery'}">
                        <div class="gallery-category">${item.category || 'Uncategorized'}</div>
                        <div class="overlay">
                            <button onclick="previewImage('${item.image}')"><i class="fa-solid fa-eye"></i></button>
                            <button onclick="editGalleryItem(${item.id})"><i class="fa-solid fa-pen"></i></button>
                            <button onclick="deleteGalleryItem(${item.id})"><i class="fa-solid fa-trash"></i></button>
                        </div>
                    </div>`;
            });
        });
    });

    window.deleteGalleryItem = function (id) {
        if (!confirm("Delete this image?")) return;
        gallery = gallery.filter(i => i.id !== id);
        saveData("gallery", gallery); displayGallery(); updateDashboard(); renderReportChart();
        addActivity("fa-trash", "Gallery Image Deleted");
        showToast("Image Deleted!", "fa-trash");
    };
    window.editGalleryItem = function (id) { openModal("gallery", id); };

    // ============================================
    // IMAGE PREVIEW
    // ============================================

    window.previewImage = function (src) {
        const pm = document.getElementById("imagePreviewModal");
        const pi = document.getElementById("previewImg");
        pi.src = src; pm.style.display = "flex";
        pm.onclick = function () { pm.style.display = "none"; };
    };

    // ============================================
    // DISPLAY VOLUNTEERS
    // ============================================

    function displayVolunteers() {
        const grid = document.getElementById("volunteers-grid");
        if (!grid) return;
        grid.innerHTML = "";
        if (volunteers.length === 0) {
            grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-users"></i><h2>No Volunteers</h2></div>`;
            return;
        }
        volunteers.forEach(item => {
            grid.innerHTML += `
                <div class="profile-card">
                    <img src="${item.image || 'https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png'}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <span>${item.role}</span>
                    ${item.email ? `<p style="font-size:13px;color:#666;margin-top:8px;">${item.email}</p>` : ""}
                    ${item.phone ? `<p style="font-size:13px;color:#666;">${item.phone}</p>` : ""}
                    <div class="actions">
                        <button onclick="editVolunteer(${item.id})">Edit</button>
                        <button onclick="deleteVolunteer(${item.id})">Delete</button>
                    </div>
                </div>`;
        });
    }

    window.deleteVolunteer = function (id) {
        if (!confirm("Delete this volunteer?")) return;
        const item = volunteers.find(i => i.id === id);
        volunteers = volunteers.filter(i => i.id !== id);
        saveData("volunteers", volunteers); displayVolunteers(); updateDashboard(); renderReportChart();
        addActivity("fa-trash", "Volunteer Deleted: " + (item?.name || "Unknown"));
        showToast("Volunteer Deleted!", "fa-trash");
    };
    window.editVolunteer = function (id) { openModal("volunteer", id); };

    // ============================================
    // DISPLAY TEAM
    // ============================================

    function displayTeam() {
        const grid = document.getElementById("team-grid");
        if (!grid) return;
        grid.innerHTML = "";
        if (team.length === 0) {
            grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-user-tie"></i><h2>No Team Members</h2></div>`;
            return;
        }
        team.forEach(item => {
            grid.innerHTML += `
                <div class="profile-card team-card">
                    <img src="${item.image || 'https://rafiqfoundation.org/upload/team/1747734101_8ced8a4b0d55aad263a4.png'}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <span>${item.role}</span>
                    ${item.bio ? `<p style="font-size:13px;color:var(--text-light);margin-top:10px;line-height:1.5;">${item.bio}</p>` : ""}
                    ${item.email ? `<p style="font-size:13px;color:var(--text-light);margin-top:8px;"><i class="fa-solid fa-envelope" style="margin-right:5px;"></i>${item.email}</p>` : ""}
                    ${item.phone ? `<p style="font-size:13px;color:var(--text-light);"><i class="fa-solid fa-phone" style="margin-right:5px;"></i>${item.phone}</p>` : ""}
                    <div class="actions">
                        <button onclick="editTeamMember(${item.id})">Edit</button>
                        <button onclick="deleteTeamMember(${item.id})">Delete</button>
                    </div>
                </div>`;
        });
    }

    window.deleteTeamMember = function (id) {
        if (!confirm("Delete this team member?")) return;
        const item = team.find(i => i.id === id);
        team = team.filter(i => i.id !== id);
        saveData("team", team); displayTeam();
        addActivity("fa-trash", "Team Member Deleted: " + (item?.name || "Unknown"));
        showToast("Team Member Deleted!", "fa-trash");
    };
    window.editTeamMember = function (id) { openModal("team", id); };

    // ============================================
    // DISPLAY DONORS
    // ============================================

    function displayDonors() {
        const grid = document.getElementById("donors-grid");
        if (!grid) return;
        grid.innerHTML = "";
        if (donors.length === 0) {
            grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-user-heart"></i><h2>No Donors Yet</h2></div>`;
            return;
        }
        const totalDonations = donors.reduce((s, d) => s + (Number(d.amount) || 0), 0);
        donors.forEach((item, index) => {
            const initials = (item.name || "?").split(" ").map(w => w[0]).join("").toUpperCase().substring(0, 2);
            grid.innerHTML += `
                <div class="donor-card">
                    <div class="donor-avatar">
                        ${item.image ? `<img src="${item.image}" alt="${item.name}">` : `<span class="donor-initials">${initials}</span>`}
                    </div>
                    <div class="donor-info">
                        <h3>${item.name}</h3>
                        <div class="donor-amount">$${(Number(item.amount) || 0).toLocaleString()}</div>
                        <div class="donor-details">
                            ${item.email ? `<p><i class="fa-solid fa-envelope"></i> ${item.email}</p>` : ""}
                            ${item.phone ? `<p><i class="fa-solid fa-phone"></i> ${item.phone}</p>` : ""}
                            ${item.address ? `<p><i class="fa-solid fa-location-dot"></i> ${item.address}</p>` : ""}
                            <p><i class="fa-solid fa-calendar"></i> ${item.date || "N/A"}</p>
                        </div>
                        <div class="donor-actions">
                            <button onclick="editDonor(${item.id})" title="Edit"><i class="fa-solid fa-pen"></i></button>
                            <button onclick="deleteDonor(${item.id})" title="Delete"><i class="fa-solid fa-trash"></i></button>
                        </div>
                    </div>
                </div>`;
        });
    }

    window.deleteDonor = function (id) {
        if (!confirm("Delete this donor?")) return;
        const item = donors.find(i => i.id === id);
        donors = donors.filter(i => i.id !== id);
        saveData("donors", donors); displayDonors();
        addActivity("fa-trash", "Donor Deleted: " + (item?.name || "Unknown"));
        showToast("Donor Deleted!", "fa-trash");
    };
    window.editDonor = function (id) { openModal("donor", id); };

    // ============================================
    // DISPLAY EVENTS
    // ============================================

    function displayEvents() {
        const tbody = document.getElementById("events-tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        if (events.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#999;padding:40px;">No events yet.</td></tr>`;
            return;
        }
        events.forEach((item, index) => {
            tbody.innerHTML += `
                <tr>
                    <td>${index + 1}</td>
                    <td>${item.image ? `<img src="${item.image}" alt="${item.title}" style="width:60px;height:60px;object-fit:cover;border-radius:10px;border:2px solid var(--border);">` : '<span style="color:#999;">No Image</span>'}</td>
                    <td>${item.title}</td>
                    <td>${item.date}</td>
                    <td>
                        <button onclick="editEvent(${item.id})"><i class="fa-solid fa-pen"></i></button>
                        <button onclick="deleteEvent(${item.id})"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>`;
        });
    }

    window.deleteEvent = function (id) {
        if (!confirm("Delete this event?")) return;
        const item = events.find(i => i.id === id);
        events = events.filter(i => i.id !== id);
        saveData("events", events); displayEvents(); updateDashboard(); renderReportChart();
        addActivity("fa-trash", "Event Deleted: " + (item?.title || "Unknown"));
        showToast("Event Deleted!", "fa-trash");
    };
    window.editEvent = function (id) { openModal("event", id); };

    // ============================================
    // DISPLAY DONATIONS (with goal & progress)
    // ============================================

    function displayDonations() {
        const grid = document.getElementById("donation-projects-grid");
        if (!grid) return;
        grid.innerHTML = "";
        if (donations.length === 0) {
            grid.innerHTML = `<div class="empty" style="grid-column:1/-1;"><i class="fa-solid fa-hand-holding-heart"></i><h2>No Donation Projects Yet</h2></div>`;
            return;
        }
        donations.forEach((item) => {
            const goal = Number(item.goal) || 0;
            const collected = Number(item.collected) || 0;
            const pct = goal > 0 ? Math.min(100, Math.round((collected / goal) * 100)) : 0;
            const remaining = Math.max(0, goal - collected);
            grid.innerHTML += `
                <div class="donation-project-card">
                    ${item.image ? `<div class="project-image"><img src="${item.image}" alt="${item.title}"><div class="project-status ${pct >= 100 ? 'completed' : 'active'}">${pct >= 100 ? 'Completed' : 'Active'}</div></div>` : ''}
                    <div class="project-content">
                        <h3>${item.title}</h3>
                        <p class="project-desc">${item.description || 'No description'}</p>
                        <div class="project-stats">
                            <div class="stat-row">
                                <span class="stat-label"><i class="fa-solid fa-bullseye"></i> Required</span>
                                <span class="stat-value goal">$${goal.toLocaleString()}</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label"><i class="fa-solid fa-hand-holding-dollar"></i> Collected</span>
                                <span class="stat-value collected">$${collected.toLocaleString()}</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label"><i class="fa-solid fa-clock"></i> Remaining</span>
                                <span class="stat-value remaining">$${remaining.toLocaleString()}</span>
                            </div>
                        </div>
                        <div class="project-progress">
                            <div class="progress-header">
                                <span>Progress</span>
                                <span class="progress-pct">${pct}%</span>
                            </div>
                            <div class="project-progress-bar">
                                <div class="fill" style="width:${pct}%;"></div>
                            </div>
                        </div>
                        <div class="project-actions">
                            <button onclick="editDonation(${item.id})" title="Edit"><i class="fa-solid fa-pen"></i> Edit</button>
                            <button onclick="deleteDonation(${item.id})" title="Delete"><i class="fa-solid fa-trash"></i> Delete</button>
                        </div>
                    </div>
                </div>`;
        });
    }

    window.deleteDonation = function (id) {
        if (!confirm("Delete this project?")) return;
        const item = donations.find(i => i.id === id);
        donations = donations.filter(i => i.id !== id);
        saveData("donations", donations); displayDonations(); updateDonationSummary(); renderDonationsChart(); renderReportChart();
        addActivity("fa-trash", "Project Deleted: " + (item?.title || "Unknown"));
        showToast("Project Deleted!", "fa-trash");
    };
    window.editDonation = function (id) { openModal("donation", id); };

    // ============================================
    // DISPLAY MESSAGES
    // ============================================

    function displayMessages() {
        const tbody = document.getElementById("messages-tbody");
        if (!tbody) return;
        tbody.innerHTML = "";
        if (messages.length === 0) {
            tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#999;padding:40px;">No messages yet.</td></tr>`;
            return;
        }
        messages.forEach((item, index) => {
            tbody.innerHTML += `
                <tr style="${!item.read ? 'background:#fef9f0;' : ''}">
                    <td>${index + 1}</td>
                    <td><strong>${item.name}</strong> ${!item.read ? '<span style="background:var(--secondary);color:#222;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600;">New</span>' : ''}</td>
                    <td>${item.email}</td>
                    <td>${item.message}</td>
                    <td>${item.date}</td>
                    <td>
                        <button onclick="markMessageRead(${item.id})" title="Mark as read"><i class="fa-solid fa-check"></i></button>
                        <button onclick="deleteMessage(${item.id})"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>`;
        });
    }

    window.markMessageRead = function (id) {
        let item = messages.find(i => i.id === id);
        if (item) { item.read = true; saveData("messages", messages); displayMessages(); updateDashboard(); showToast("Message marked as read"); }
    };

    window.deleteMessage = function (id) {
        if (!confirm("Delete this message?")) return;
        messages = messages.filter(i => i.id !== id);
        saveData("messages", messages); displayMessages(); updateDashboard();
        showToast("Message Deleted!", "fa-trash");
    };

    // ============================================
    // SETTINGS
    // ============================================

    const settingsForm = document.getElementById("settings-form");
    if (settingsForm) {
        const savedSettings = JSON.parse(localStorage.getItem("settings")) || {};
        document.getElementById("settings-org").value = savedSettings.organization || "";
        document.getElementById("settings-email").value = savedSettings.email || "";
        document.getElementById("settings-phone").value = savedSettings.phone || "";
        document.getElementById("settings-address").value = savedSettings.address || "";
        document.getElementById("settings-language").value = savedSettings.language || "en";

        settingsForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const s = JSON.parse(localStorage.getItem("settings")) || {};
            s.organization = document.getElementById("settings-org").value;
            s.email = document.getElementById("settings-email").value;
            s.phone = document.getElementById("settings-phone").value;
            s.address = document.getElementById("settings-address").value;
            s.language = document.getElementById("settings-language").value;
            localStorage.setItem("settings", JSON.stringify(s));
            showToast("Settings Saved Successfully!");
        });
    }

    // Security form
    const securityForm = document.getElementById("security-form");
    securityForm?.addEventListener("submit", (e) => {
        e.preventDefault();
        const pw = document.getElementById("settings-password").value;
        const confirmPw = document.getElementById("settings-confirm-pw").value;
        if (!pw || pw.length < 6) { showToast("Password must be at least 6 characters", "fa-exclamation-triangle"); return; }
        if (pw !== confirmPw) { showToast("Passwords do not match", "fa-exclamation-triangle"); return; }
        const s = JSON.parse(localStorage.getItem("settings")) || {};
        s.passwordChanged = true;
        s.lastPasswordChange = new Date().toLocaleDateString();
        localStorage.setItem("settings", JSON.stringify(s));
        securityForm.reset();
        showToast("Password Updated Successfully!");
    });

    // Export data
    document.getElementById("export-data-btn")?.addEventListener("click", () => {
        const data = {
            achievements, gallery, volunteers, team, events, donations, donors, messages, notifications,
            settings: JSON.parse(localStorage.getItem("settings")) || {},
            exportDate: new Date().toLocaleDateString()
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url; a.download = "rafiq-foundation-data.json"; a.click();
        URL.revokeObjectURL(url);
        showToast("Data Exported Successfully!", "fa-download");
    });

    // Clear data
    document.getElementById("clear-data-btn")?.addEventListener("click", () => {
        if (!confirm("Are you sure? This will delete ALL data permanently!")) return;
        localStorage.clear();
        showToast("All data cleared. Reloading...", "fa-trash");
        setTimeout(() => location.reload(), 1500);
    });

    // ============================================
    // LOGOUT
    // ============================================

    document.querySelector(".logout button")?.addEventListener("click", () => {
        if (confirm("Are you sure you want to logout?")) {
            showToast("Logging out...", "fa-right-from-bracket");
            setTimeout(() => location.reload(), 1000);
        }
    });

    // ============================================
    // RIPPLE EFFECT
    // ============================================

    document.querySelectorAll("button").forEach(button => {
        button.addEventListener("click", function (e) {
            const ripple = document.createElement("span");
            const diameter = 80;
            ripple.style.width = diameter + "px";
            ripple.style.height = diameter + "px";
            ripple.style.left = (e.offsetX - diameter / 2) + "px";
            ripple.style.top = (e.offsetY - diameter / 2) + "px";
            ripple.className = "ripple";
            ripple.style.cssText = `position:absolute;border-radius:50%;background:rgba(255,255,255,0.3);pointer-events:none;width:${diameter}px;height:${diameter}px;`;
            this.style.position = "relative";
            this.style.overflow = "hidden";
            this.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // ============================================
    // INITIALIZE ALL
    // ============================================

    displayAchievements();
    displayGallery();
    displayVolunteers();
    displayTeam();
    displayDonors();
    displayEvents();
    displayDonations();
    displayMessages();
    updateDashboard();
    updateDonationSummary();
    updateActivityList();

    animateCounter("achievements-count", achievements.length);
    animateCounter("gallery-count", gallery.length);
    animateCounter("volunteer-count", volunteers.length);
    animateCounter("events-count", events.length);

    setTimeout(() => showToast("Welcome to Rafiq Foundation Admin", "fa-hand-holding-heart"), 1000);
});
